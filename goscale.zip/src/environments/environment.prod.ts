export const environment = {
  production: true,
  apiUrl: 'https://api.myjson.com/bins/',
  questionsUrl: 'dck5b',
  answersUrl: 'hildr'
};
